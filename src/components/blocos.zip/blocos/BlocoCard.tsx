"use client";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  CheckSquare,
  Activity,
  Clock,
  ListTodo,
  CalendarDays,
  Calculator,
  Layers,
  BookOpen,
  FileText,
  ExternalLink,
  MoreHorizontal,
  Copy,
  Trash2,
  Plus,
  GripVertical,
  CornerDownRight,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { useState, useRef } from "react";
import { CriarBlocoModal } from "@/components/blocos/CriarBlocoModal";
import { TIPO_BLOCO_META } from "@/lib/bloco-utils";
import type { Bloco, CreateBlocoPayload } from "@/types/bloco";

interface BlocoCardProps {
  bloco: Bloco;
  nucleoId: string;
  onDelete?: () => void;
  onEdit?: () => void;
  onDuplicate?: () => void;
  onCreateBloco?: (payload: CreateBlocoPayload) => Promise<void>;
  isDeleting?: boolean;
  isCreating?: boolean;
  compact?: boolean;
  depth?: number;
}

const BLOCO_ICONS: Record<string, React.ElementType> = {
  tarefas: CheckSquare,
  habitos: Activity,
  habito: Activity,
  timer: Clock,
  timers: Clock,
  notas: BookOpen,
  lista: ListTodo,
  calendario: CalendarDays,
  calculo: Calculator,
  colecoes: Layers,
};

const BLOCO_COLORS: Record<string, string> = {
  tarefas:
    "bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800",
  habitos:
    "bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800",
  timer:
    "bg-orange-50 dark:bg-orange-950/20 border-orange-200 dark:border-orange-800",
  notas:
    "bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800",
  lista:
    "bg-purple-50 dark:bg-purple-950/20 border-purple-200 dark:border-purple-800",
  calendario:
    "bg-cyan-50 dark:bg-cyan-950/20 border-cyan-200 dark:border-cyan-800",
  colecoes:
    "bg-indigo-50 dark:bg-indigo-950/20 border-indigo-200 dark:border-indigo-800",
};

const BLOCO_ICON_COLORS: Record<string, string> = {
  tarefas: "text-blue-600 dark:text-blue-400",
  habitos: "text-green-600 dark:text-green-400",
  timer: "text-orange-600 dark:text-orange-400",
  notas: "text-amber-600 dark:text-amber-400",
  lista: "text-purple-600 dark:text-purple-400",
  calendario: "text-cyan-600 dark:text-cyan-400",
  colecoes: "text-indigo-600 dark:text-indigo-400",
};

export function BlocoCard({
  bloco,
  nucleoId,
  onDelete,
  onEdit,
  onDuplicate,
  onCreateBloco,
  isDeleting = false,
  isCreating = false,
  compact = true,
  depth = 0,
}: BlocoCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [modalCriarAberto, setModalCriarAberto] = useState(false);
  const [modalParentId, setModalParentId] = useState<string | null>(null);
  const [modalPosicao, setModalPosicao] = useState<number | undefined>(
    undefined,
  );
  const cardRef = useRef<HTMLDivElement>(null);

  const IconComponent = BLOCO_ICONS[bloco.tipo] || FileText;
  const bgColor = BLOCO_COLORS[bloco.tipo] || "bg-muted/50 border-border";
  const iconColor = BLOCO_ICON_COLORS[bloco.tipo] || "text-muted-foreground";
  const tituloExibicao =
    bloco.titulo || TIPO_BLOCO_META[bloco.tipo]?.rotulo || bloco.tipo;

  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData("text/plain", bloco.id);
    e.dataTransfer.effectAllowed = "move";
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragEnd = () => {
    setIsDragging(false);
  };

  const handleOpenSubBloco = () => {
    setModalParentId(bloco.id);
    setModalPosicao(undefined);
    setModalCriarAberto(true);
  };

  const handleOpenAbaixo = () => {
    setModalParentId(bloco.parentId || null);
    setModalPosicao((bloco.posicao || 0) + 1);
    setModalCriarAberto(true);
  };

  const handleCriarBloco = async (payload: CreateBlocoPayload) => {
    if (onCreateBloco) {
      await onCreateBloco({
        ...payload,
        parentId: modalParentId,
        posicao: modalPosicao,
      });
    }
    setModalCriarAberto(false);
  };

  return (
    <>
      <motion.div
        ref={cardRef}
        layout
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ duration: 0.2 }}
        className={cn("group relative", depth > 0 && "ml-6 md:ml-8 lg:ml-12")}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Indicador de profundidade (sub-bloco) */}
        {depth > 0 && (
          <div className="absolute -left-5 top-1/2 -translate-y-1/2 md:-left-6">
            <div className="flex items-center gap-0.5">
              <CornerDownRight className="h-3 w-3 text-muted-foreground/50" />
              <div className="w-4 h-px bg-border" />
            </div>
          </div>
        )}

        {/* Drag Handle */}
        <div
          className={cn(
            "absolute -left-8 top-1/2 -translate-y-1/2 transition-all duration-200",
            "md:-left-10",
            isHovered
              ? "opacity-100 translate-x-0"
              : "opacity-0 -translate-x-1",
          )}
        >
          <div
            className="cursor-grab active:cursor-grabbing p-1.5 rounded-lg hover:bg-accent/50 transition-colors"
            draggable
            onDragStart={handleDragStart}
            onDragEnd={handleDragEnd}
            title="Arraste para reordenar"
          >
            <GripVertical className="h-4 w-4 text-muted-foreground" />
          </div>
        </div>

        {/* Card Container */}
        <div
          className={cn(
            "w-full border rounded-lg p-4 transition-all duration-200",
            bgColor,
            isDragging &&
              "opacity-50 shadow-lg ring-2 ring-primary scale-[1.02]",
            isHovered && "shadow-md",
          )}
        >
          {/* Link para tela cheia (apenas no modo compacto) */}
          {compact && (
            <Link
              href={`/dashboard/nucleos/${nucleoId}/blocos/${bloco.id}`}
              className="absolute inset-0 z-0 rounded-lg"
              aria-label={`Abrir bloco ${tituloExibicao}`}
            />
          )}

          {/* Conteúdo do Card */}
          <div className="flex items-start justify-between gap-4 relative z-10">
            {/* Ícone + Informações */}
            <div className="flex items-start gap-3 flex-1 min-w-0">
              <div className={cn("p-2 rounded-md flex-shrink-0", bgColor)}>
                <IconComponent className={cn("w-5 h-5", iconColor)} />
              </div>

              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-sm md:text-base truncate text-foreground">
                  {tituloExibicao}
                </h3>
                {!compact && (
                  <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">
                    {TIPO_BLOCO_META[bloco.tipo]?.descricao ||
                      "Clique para editar"}
                  </p>
                )}
              </div>
            </div>

            {/* Menu de Ações */}
            <div
              className="relative z-20 shrink-0"
              data-no-nav="true"
              onClick={(e) => e.preventDefault()}
            >
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button
                    className={cn(
                      "p-1.5 rounded-lg transition-all duration-200",
                      "hover:bg-black/5 dark:hover:bg-white/5",
                      isHovered ? "opacity-100" : "opacity-0 md:opacity-100",
                    )}
                    disabled={isDeleting}
                  >
                    <MoreHorizontal className="h-4 w-4 text-muted-foreground" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem onClick={onEdit} className="gap-2">
                    <ExternalLink className="h-4 w-4" />
                    <span>Abrir em tela cheia</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={onDuplicate} className="gap-2">
                    <Copy className="h-4 w-4" />
                    <span>Duplicar</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={handleOpenSubBloco}
                    className="gap-2"
                  >
                    <Plus className="h-4 w-4" />
                    <span>Adicionar sub-bloco</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={handleOpenAbaixo}
                    className="gap-2"
                  >
                    <Plus className="h-4 w-4" />
                    <span>Adicionar abaixo</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={onDelete}
                    className="gap-2 text-destructive focus:text-destructive"
                    disabled={isDeleting}
                  >
                    <Trash2 className="h-4 w-4" />
                    <span>{isDeleting ? "Excluindo..." : "Excluir"}</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>

        {/* Botão de ação rápida (adicionar abaixo) */}
        <AnimatePresence>
          {isHovered && onCreateBloco && compact && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 10 }}
              transition={{ duration: 0.15 }}
              onClick={(e) => {
                e.preventDefault();
                handleOpenAbaixo();
              }}
              className="absolute -bottom-3 left-1/2 -translate-x-1/2 z-20"
            >
              <div className="bg-background border border-border rounded-full shadow-md hover:shadow-lg transition-shadow">
                <div className="p-1">
                  <Plus className="h-3 w-3 text-muted-foreground" />
                </div>
              </div>
            </motion.button>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Modal de criação de bloco */}
      {onCreateBloco && (
        <CriarBlocoModal
          open={modalCriarAberto}
          onClose={() => setModalCriarAberto(false)}
          onConfirm={handleCriarBloco}
          nucleoId={nucleoId}
          isCreating={isCreating}
          parentId={modalParentId}
        />
      )}
    </>
  );
}
